import { useMemo, useState } from 'react';
import { supabase, type Resume, type Job, type Analysis, type Course } from '../lib/supabase';
import { scoreMatch, recommendCourses } from '../lib/skills';
import { useAuth } from '../context/AuthContext';
import { Target, Loader2, TrendingUp, BookOpen, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';

type Props = {
  resumes: Resume[];
  jobs: Job[];
  courses: Course[];
  onAnalysis: () => void;
  preselectJobId?: string | null;
};

export default function Analyze({ resumes, jobs, courses, onAnalysis, preselectJobId }: Props) {
  const { user } = useAuth();
  const [resumeId, setResumeId] = useState<string>('');
  const [jobId, setJobId] = useState<string>(preselectJobId ?? '');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Analysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const resume = resumes.find((r) => r.id === resumeId) ?? null;
  const job = jobs.find((j) => j.id === jobId) ?? null;

  const livePreview = useMemo(() => {
    if (!resume || !job) return null;
    return scoreMatch(resume.skills, job.required_skills);
  }, [resume, job]);

  const courseRecs = useMemo(() => {
    if (!result) return [];
    return recommendCourses(result.missing_skills, courses);
  }, [result, courses]);

  const run = async () => {
    setError(null);
    setResult(null);
    if (!resume || !job || !user) return;
    setBusy(true);
    try {
      const m = scoreMatch(resume.skills, job.required_skills);
      const { data, error } = await supabase
        .from('analyses')
        .insert({
          resume_id: resume.id,
          job_id: job.id,
          match_score: m.score,
          matched_skills: m.matched,
          missing_skills: m.missing,
        })
        .select()
        .single();
      if (error) throw new Error(error.message);
      setResult(data);
      onAnalysis();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const scoreColor = (s: number) =>
    s >= 75 ? 'text-emerald-400' : s >= 50 ? 'text-amber-400' : 'text-rose-400';
  const ringColor = (s: number) =>
    s >= 75 ? '#34d399' : s >= 50 ? '#fbbf24' : '#fb7185';

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-100 mb-1">AI Skill Analysis</h2>
        <p className="text-sm text-slate-400">Pick a resume and a job. We compute a match score using skill overlap with partial credit for related skills.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">Your Resume</label>
          <select
            value={resumeId}
            onChange={(e) => setResumeId(e.target.value)}
            className="w-full bg-slate-900/60 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
          >
            <option value="">Select a resume...</option>
            {resumes.map((r) => (
              <option key={r.id} value={r.id}>{r.filename}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">Target Job</label>
          <select
            value={jobId}
            onChange={(e) => setJobId(e.target.value)}
            className="w-full bg-slate-900/60 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
          >
            <option value="">Select a job...</option>
            {jobs.map((j) => (
              <option key={j.id} value={j.id}>{j.title} — {j.company}</option>
            ))}
          </select>
        </div>
      </div>

      <button
        onClick={run}
        disabled={!resumeId || !jobId || busy}
        className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-sky-500 text-white text-sm font-semibold flex items-center gap-2 hover:opacity-90 transition disabled:opacity-40"
      >
        {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Target className="w-4 h-4" />}
        Run Analysis
      </button>

      {error && <p className="text-sm text-rose-400">{error}</p>}

      {/* Live preview */}
      {livePreview && !result && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <p className="text-xs text-slate-500 mb-3">Live preview (updates as you pick):</p>
          <div className="flex items-center gap-4">
            <ScoreRing score={livePreview.score} color={ringColor(livePreview.score)} />
            <div className="flex-1">
              <p className="text-sm text-slate-300">
                <span className={scoreColor(livePreview.score)}>{livePreview.matched.length}</span> / {job?.required_skills.length} skills matched
              </p>
              {livePreview.partial.length > 0 && (
                <p className="text-xs text-slate-500 mt-1">
                  +{livePreview.partial.length} related skill{livePreview.partial.length > 1 ? 's' : ''} give partial credit
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Result */}
      {result && job && resume && (
        <div className="space-y-5">
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
            <div className="flex flex-col md:flex-row md:items-center gap-6">
              <ScoreRing score={result.match_score} color={ringColor(result.match_score)} size="lg" />
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-slate-100">{job.title}</h3>
                <p className="text-sm text-slate-400">{job.company} · {job.location}</p>
                <div className="grid grid-cols-3 gap-3 mt-4">
                  <Stat icon={<CheckCircle2 className="w-4 h-4 text-emerald-400" />} label="Matched" value={result.matched_skills.length} />
                  <Stat icon={<XCircle className="w-4 h-4 text-rose-400" />} label="Missing" value={result.missing_skills.length} />
                  <Stat icon={<TrendingUp className="w-4 h-4 text-sky-400" />} label="Score" value={`${result.match_score}%`} />
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
              <h4 className="text-sm font-semibold text-emerald-300 mb-3 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" /> Matched Skills
              </h4>
              {result.matched_skills.length === 0 ? (
                <p className="text-sm text-slate-500">No direct matches yet.</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {result.matched_skills.map((s) => (
                    <span key={s} className="text-xs px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">{s}</span>
                  ))}
                </div>
              )}
            </div>
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
              <h4 className="text-sm font-semibold text-rose-300 mb-3 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" /> Skill Gaps
              </h4>
              {result.missing_skills.length === 0 ? (
                <p className="text-sm text-slate-500">No gaps — you're a great match!</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {result.missing_skills.map((s) => (
                    <span key={s} className="text-xs px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-300 border border-rose-500/20">{s}</span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Course recommendations */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
            <h4 className="text-sm font-semibold text-sky-300 mb-4 flex items-center gap-2">
              <BookOpen className="w-4 h-4" /> Recommended Courses to Close Gaps
            </h4>
            {courseRecs.length === 0 ? (
              <p className="text-sm text-slate-500">No courses needed — or no matching courses found.</p>
            ) : (
              <div className="grid sm:grid-cols-2 gap-3">
                {courseRecs.map(({ course, overlap }) => (
                  <a
                    key={course.id}
                    href={course.url ?? '#'}
                    target="_blank"
                    rel="noreferrer"
                    className="block bg-slate-800/50 border border-slate-700 rounded-xl p-4 hover:border-sky-500/50 transition"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-sm font-medium text-slate-100">{course.title}</p>
                        <p className="text-xs text-slate-500">{course.provider}{course.level ? ` · ${course.level}` : ''}</p>
                      </div>
                      <span className="text-xs px-2 py-0.5 rounded-md bg-sky-500/10 text-sky-300 border border-sky-500/20 shrink-0">
                        {overlap.length} match{overlap.length > 1 ? 'es' : ''}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {overlap.map((s) => (
                        <span key={s} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-700/60 text-slate-300">{s}</span>
                      ))}
                    </div>
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="bg-slate-800/50 rounded-xl p-3">
      <div className="flex items-center gap-1.5 text-xs text-slate-400">{icon}{label}</div>
      <p className="text-lg font-semibold text-slate-100 mt-1">{value}</p>
    </div>
  );
}

function ScoreRing({ score, color, size = 'md' }: { score: number; color: string; size?: 'md' | 'lg' }) {
  const dim = size === 'lg' ? 120 : 80;
  const stroke = size === 'lg' ? 10 : 7;
  const r = (dim - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (score / 100) * c;
  return (
    <div className="relative shrink-0" style={{ width: dim, height: dim }}>
      <svg width={dim} height={dim} className="-rotate-90">
        <circle cx={dim / 2} cy={dim / 2} r={r} stroke="#1e293b" strokeWidth={stroke} fill="none" />
        <circle
          cx={dim / 2}
          cy={dim / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={c}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.6s ease' }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className={`font-bold ${size === 'lg' ? 'text-2xl' : 'text-base'} text-slate-100`}>{score}%</span>
      </div>
    </div>
  );
}
