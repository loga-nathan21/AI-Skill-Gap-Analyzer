import { useMemo } from 'react';
import { supabase, type Resume, type Job, type Analysis } from '../lib/supabase';
import { scoreMatch } from '../lib/skills';
import { Briefcase, TrendingUp, Trash2, MapPin, Building2, Loader2 } from 'lucide-react';
import { useState } from 'react';

type Props = {
  resumes: Resume[];
  jobs: Job[];
  analyses: Analysis[];
  onChanged: () => void;
  onAnalyzeJob: (jobId: string) => void;
};

export default function Dashboard({ resumes, jobs, analyses, onChanged, onAnalyzeJob }: Props) {
  const [removing, setRemoving] = useState<string | null>(null);

  // Best resume = the one with most skills (most recent if tie)
  const bestResume = useMemo(() => {
    if (resumes.length === 0) return null;
    return [...resumes].sort((a, b) => {
      if (b.skills.length !== a.skills.length) return b.skills.length - a.skills.length;
      return +new Date(b.created_at) - +new Date(a.created_at);
    })[0];
  }, [resumes]);

  // Job recommendations: score best resume against all jobs, sort desc
  const jobRecs = useMemo(() => {
    if (!bestResume) return [];
    return jobs
      .map((j) => {
        const m = scoreMatch(bestResume.skills, j.required_skills);
        return { job: j, score: m.score, missing: m.missing.length };
      })
      .sort((a, b) => b.score - a.score);
  }, [bestResume, jobs]);

  const avgScore = analyses.length
    ? Math.round(analyses.reduce((s, a) => s + a.match_score, 0) / analyses.length)
    : 0;

  const deleteAnalysis = async (id: string) => {
    setRemoving(id);
    await supabase.from('analyses').delete().eq('id', id);
    setRemoving(null);
    onChanged();
  };

  const jobTitle = (id: string) => jobs.find((j) => j.id === id);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-100 mb-1">Prediction Dashboard</h2>
        <p className="text-sm text-slate-400">Overview of your analyses and AI job recommendations.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Resumes" value={resumes.length} icon={<Briefcase className="w-4 h-4" />} tint="emerald" />
        <StatCard label="Analyses" value={analyses.length} icon={<TrendingUp className="w-4 h-4" />} tint="sky" />
        <StatCard label="Avg Match" value={`${avgScore}%`} icon={<TrendingUp className="w-4 h-4" />} tint="amber" />
        <StatCard label="Jobs Tracked" value={jobs.length} icon={<Briefcase className="w-4 h-4" />} tint="violet" />
      </div>

      {/* Job recommendations */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-emerald-400" /> Job Recommendations
          </h3>
          {bestResume && <span className="text-xs text-slate-500">based on {bestResume.filename}</span>}
        </div>
        {!bestResume ? (
          <p className="text-sm text-slate-500">Upload a resume to see personalized job recommendations.</p>
        ) : jobRecs.length === 0 ? (
          <p className="text-sm text-slate-500">No jobs available yet.</p>
        ) : (
          <div className="space-y-2.5">
            {jobRecs.map(({ job, score, missing }) => (
              <div key={job.id} className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-3.5 hover:border-emerald-500/40 transition">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-100">{job.title}</p>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                      <span className="flex items-center gap-1"><Building2 className="w-3 h-3" />{job.company}</span>
                      {job.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{job.location}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className={`text-sm font-bold ${score >= 75 ? 'text-emerald-400' : score >= 50 ? 'text-amber-400' : 'text-rose-400'}`}>
                        {score}%
                      </div>
                      <div className="text-[10px] text-slate-500">{missing} gaps</div>
                    </div>
                    <button
                      onClick={() => onAnalyzeJob(job.id)}
                      className="text-xs px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 hover:bg-emerald-500/20 transition"
                    >
                      Analyze
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Analysis history */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
        <h3 className="text-sm font-semibold text-slate-200 mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-sky-400" /> Analysis History
        </h3>
        {analyses.length === 0 ? (
          <p className="text-sm text-slate-500">No analyses yet. Run one from the Analyze tab.</p>
        ) : (
          <div className="space-y-2.5">
            {[...analyses].reverse().map((a) => {
              const j = jobTitle(a.job_id);
              return (
                <div key={a.id} className="flex items-center justify-between gap-3 bg-slate-800/40 border border-slate-700/60 rounded-xl p-3.5">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-200 truncate">{j?.title ?? 'Unknown job'}</p>
                    <p className="text-xs text-slate-500">
                      {j?.company} · {new Date(a.created_at).toLocaleString()}
                    </p>
                    <div className="flex gap-3 mt-1.5 text-xs">
                      <span className="text-emerald-400">{a.matched_skills.length} matched</span>
                      <span className="text-rose-400">{a.missing_skills.length} gaps</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className={`text-lg font-bold ${a.match_score >= 75 ? 'text-emerald-400' : a.match_score >= 50 ? 'text-amber-400' : 'text-rose-400'}`}>
                      {a.match_score}%
                    </div>
                    <button
                      onClick={() => deleteAnalysis(a.id)}
                      disabled={removing === a.id}
                      className="text-slate-500 hover:text-rose-400 transition p-1"
                    >
                      {removing === a.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, tint }: { label: string; value: React.ReactNode; icon: React.ReactNode; tint: 'emerald' | 'sky' | 'amber' | 'violet' }) {
  const colors = {
    emerald: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
    sky: 'text-sky-400 bg-sky-500/10 border-sky-500/20',
    amber: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
    violet: 'text-violet-400 bg-violet-500/10 border-violet-500/20',
  };
  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
      <div className={`inline-flex p-1.5 rounded-lg border ${colors[tint]} mb-2`}>{icon}</div>
      <p className="text-2xl font-bold text-slate-100">{value}</p>
      <p className="text-xs text-slate-500">{label}</p>
    </div>
  );
}
