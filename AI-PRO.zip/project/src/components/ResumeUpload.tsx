import { useState, useRef } from 'react';
import { supabase, type Resume } from '../lib/supabase';
import { extractSkills } from '../lib/skills';
import { useAuth } from '../context/AuthContext';
import { Upload, FileText, Loader2, Trash2, X, Sparkles } from 'lucide-react';

type Props = {
  resumes: Resume[];
  onSaved: () => void;
};

export default function ResumeUpload({ resumes, onSaved }: Props) {
  const { user } = useAuth();
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [pasteText, setPasteText] = useState('');
  const [showPaste, setShowPaste] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const saveResume = async (filename: string, content: string) => {
    if (!user) return;
    const skills = extractSkills(content);
    const { error } = await supabase.from('resumes').insert({
      filename,
      content,
      skills,
    });
    if (error) throw new Error(error.message);
    onSaved();
  };

  const handleFile = async (file: File) => {
    setError(null);
    setBusy(true);
    try {
      const isText = file.type.startsWith('text/') || /\.(txt|md)$/i.test(file.name);
      if (!isText) {
        // Best-effort: read as text anyway; many .txt-like files work.
        const text = await file.text();
        if (!text.trim()) {
          setError('Could not read file. Please paste your resume text instead.');
          return;
        }
        await saveResume(file.name, text);
      } else {
        const text = await file.text();
        if (!text.trim()) {
          setError('That file looks empty.');
          return;
        }
        await saveResume(file.name, text);
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  const submitPaste = async () => {
    setError(null);
    if (!pasteText.trim()) return;
    setBusy(true);
    try {
      await saveResume('pasted-resume.txt', pasteText.trim());
      setPasteText('');
      setShowPaste(false);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id: string) => {
    await supabase.from('resumes').delete().eq('id', id);
    onSaved();
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-100 mb-1">Your Resumes</h2>
        <p className="text-sm text-slate-400">Upload a .txt resume or paste the text. We extract skills automatically.</p>
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={`rounded-2xl border-2 border-dashed p-8 text-center transition ${
          dragging ? 'border-emerald-500 bg-emerald-500/5' : 'border-slate-700 bg-slate-900/40'
        }`}
      >
        <input
          ref={fileRef}
          type="file"
          accept=".txt,.md,text/plain"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />
        <Upload className="w-10 h-10 text-emerald-400 mx-auto mb-3" />
        <p className="text-slate-300 text-sm mb-1">Drag &amp; drop a .txt resume here</p>
        <p className="text-slate-500 text-xs mb-4">or</p>
        <div className="flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => fileRef.current?.click()}
            disabled={busy}
            className="px-4 py-2 rounded-xl bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-400 transition flex items-center gap-2 disabled:opacity-50"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
            Choose File
          </button>
          <button
            onClick={() => setShowPaste((s) => !s)}
            className="px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-sm font-medium hover:bg-slate-700 transition flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" /> Paste Text
          </button>
        </div>
        {error && <p className="mt-4 text-sm text-rose-400">{error}</p>}
      </div>

      {showPaste && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-slate-200">Paste resume text</h3>
            <button onClick={() => setShowPaste(false)} className="text-slate-500 hover:text-slate-300">
              <X className="w-4 h-4" />
            </button>
          </div>
          <textarea
            value={pasteText}
            onChange={(e) => setPasteText(e.target.value)}
            rows={8}
            placeholder="Paste your resume content here..."
            className="w-full bg-slate-800/60 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
          />
          <button
            onClick={submitPaste}
            disabled={busy || !pasteText.trim()}
            className="mt-3 px-4 py-2 rounded-xl bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-400 transition disabled:opacity-50 flex items-center gap-2"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            Analyze Resume
          </button>
        </div>
      )}

      <div className="space-y-3">
        {resumes.length === 0 && (
          <p className="text-sm text-slate-500 text-center py-6">No resumes yet. Upload one to get started.</p>
        )}
        {resumes.map((r) => (
          <div key={r.id} className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 min-w-0">
                <div className="p-2 rounded-lg bg-slate-800">
                  <FileText className="w-4 h-4 text-sky-400" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-200 truncate">{r.filename}</p>
                  <p className="text-xs text-slate-500">{new Date(r.created_at).toLocaleDateString()}</p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {r.skills.slice(0, 8).map((s) => (
                      <span key={s} className="text-xs px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                        {s}
                      </span>
                    ))}
                    {r.skills.length > 8 && (
                      <span className="text-xs px-2 py-0.5 text-slate-500">+{r.skills.length - 8} more</span>
                    )}
                  </div>
                </div>
              </div>
              <button
                onClick={() => remove(r.id)}
                className="text-slate-500 hover:text-rose-400 transition p-1"
                title="Delete resume"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
