import { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { supabase, type Resume, type Job, type Course, type Analysis } from './lib/supabase';
import AuthScreen from './components/AuthScreen';
import ResumeUpload from './components/ResumeUpload';
import Analyze from './components/Analyze';
import Dashboard from './components/Dashboard';
import { Brain, LayoutDashboard, Upload, Target, LogOut, Loader2 } from 'lucide-react';

type Tab = 'dashboard' | 'resumes' | 'analyze';

function Shell() {
  const { user, loading, signOut } = useAuth();
  const [tab, setTab] = useState<Tab>('dashboard');
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [preload, setPreload] = useState(true);
  const [pendingJobId, setPendingJobId] = useState<string | null>(null);

  const loadAll = async () => {
    const [r, j, c, a] = await Promise.all([
      supabase.from('resumes').select('*').order('created_at', { ascending: false }),
      supabase.from('jobs').select('*').order('posted_at', { ascending: false }),
      supabase.from('courses').select('*'),
      supabase.from('analyses').select('*').order('created_at', { ascending: false }),
    ]);
    setResumes((r.data as Resume[]) ?? []);
    setJobs((j.data as Job[]) ?? []);
    setCourses((c.data as Course[]) ?? []);
    setAnalyses((a.data as Analysis[]) ?? []);
  };

  useEffect(() => {
    if (!user) return;
    setPreload(true);
    loadAll().finally(() => setPreload(false));
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-emerald-400 animate-spin" />
      </div>
    );
  }

  if (!user) return <AuthScreen />;

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'resumes', label: 'Resumes', icon: <Upload className="w-4 h-4" /> },
    { id: 'analyze', label: 'Analyze', icon: <Target className="w-4 h-4" /> },
  ];

  const handleAnalyzeJob = (jobId: string) => {
    setPendingJobId(jobId);
    setTab('analyze');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-gradient-to-br from-emerald-400 to-sky-500">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-semibold leading-tight">SkillGap AI</p>
              <p className="text-[11px] text-slate-500 leading-tight">AI Skill Gap Analyzer</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400 hidden sm:block truncate max-w-[180px]">{user.email}</span>
            <button
              onClick={signOut}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 transition"
            >
              <LogOut className="w-3.5 h-3.5" /> Sign Out
            </button>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <nav className="sticky top-16 z-10 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="max-w-5xl mx-auto px-4 flex gap-1">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition ${
                tab === t.id
                  ? 'border-emerald-500 text-emerald-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.icon} {t.label}
            </button>
          ))}
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-5xl mx-auto px-4 py-8">
        {preload ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 text-emerald-400 animate-spin" />
          </div>
        ) : tab === 'dashboard' ? (
          <Dashboard
            resumes={resumes}
            jobs={jobs}
            analyses={analyses}
            onChanged={loadAll}
            onAnalyzeJob={handleAnalyzeJob}
          />
        ) : tab === 'resumes' ? (
          <ResumeUpload resumes={resumes} onSaved={loadAll} />
        ) : (
          <Analyze
            key={pendingJobId ?? 'analyze'}
            resumes={resumes}
            jobs={jobs}
            courses={courses}
            onAnalysis={loadAll}
            preselectJobId={pendingJobId}
          />
        )}
      </main>

      <footer className="max-w-5xl mx-auto px-4 py-6 text-center text-xs text-slate-600">
        SkillGap AI · ML-powered skill matching with Jaccard similarity + semantic partial credit
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  );
}
