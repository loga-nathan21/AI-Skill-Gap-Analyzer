// Lightweight ML-style skill extraction and matching.
// Extracts known skills from free text using a curated keyword bank,
// then scores resume-vs-job fit using Jaccard similarity with a
// partial-credit bonus for semantically related skills.

export const SKILL_BANK: string[] = [
  // Languages
  'JavaScript', 'TypeScript', 'Python', 'Java', 'C++', 'C#', 'Go', 'Rust', 'Ruby', 'PHP', 'Swift', 'Kotlin', 'Scala', 'R', 'MATLAB', 'Bash', 'SQL',
  // Frontend
  'React', 'Redux', 'Next.js', 'Vue', 'Angular', 'Svelte', 'HTML', 'CSS', 'Tailwind', 'Sass', 'Bootstrap', 'Material UI', 'React Native',
  // Backend
  'Node.js', 'Express', 'NestJS', 'Django', 'Flask', 'FastAPI', 'Spring', 'Rails', 'GraphQL', 'REST API', 'gRPC', 'WebSockets',
  // Database
  'MongoDB', 'PostgreSQL', 'MySQL', 'SQLite', 'Redis', 'Firebase', 'Supabase', 'DynamoDB', 'Cassandra', 'Elasticsearch',
  // ML / Data
  'Machine Learning', 'Deep Learning', 'TensorFlow', 'PyTorch', 'Scikit-learn', 'Keras', 'Pandas', 'NumPy', 'Matplotlib', 'Seaborn', 'NLTK', 'spaCy', 'OpenCV', 'Statistics', 'NLP', 'Computer Vision', 'Reinforcement Learning', 'Data Analysis', 'Data Visualization',
  // Cloud / DevOps
  'AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes', 'Terraform', 'CI/CD', 'Jenkins', 'GitHub Actions', 'Linux', 'Nginx', 'MLOps',
  // Tools
  'Git', 'GitHub', 'Jira', 'Figma', 'Tableau', 'Power BI', 'Excel', 'Agile', 'Scrum',
  // Mobile / OS
  'iOS', 'Android',
];

// Normalized lookup: lowercase key -> canonical skill name
const SKILL_LOOKUP: Map<string, string> = new Map(
  SKILL_BANK.map((s) => [s.toLowerCase(), s])
);

// Aliases map common resume spellings/abbreviations to canonical skill.
const ALIASES: Record<string, string> = {
  'js': 'JavaScript',
  'ts': 'TypeScript',
  'py': 'Python',
  'node': 'Node.js',
  'nodejs': 'Node.js',
  'expressjs': 'Express',
  'reactjs': 'React',
  'react.js': 'React',
  'nextjs': 'Next.js',
  'next.js': 'Next.js',
  'vuejs': 'Vue',
  'vue.js': 'Vue',
  'angularjs': 'Angular',
  'tailwindcss': 'Tailwind',
  'scikit learn': 'Scikit-learn',
  'sklearn': 'Scikit-learn',
  'tf': 'TensorFlow',
  'pytorch': 'PyTorch',
  'pandas': 'Pandas',
  'numpy': 'NumPy',
  'ml': 'Machine Learning',
  'dl': 'Deep Learning',
  'postgres': 'PostgreSQL',
  'postgresql': 'PostgreSQL',
  'mongo': 'MongoDB',
  'mongodb': 'MongoDB',
  'k8s': 'Kubernetes',
  'aws': 'AWS',
  'gcp': 'GCP',
  'rest': 'REST API',
  'rest api': 'REST API',
  'restful': 'REST API',
  'ci/cd': 'CI/CD',
  'cicd': 'CI/CD',
  'c++': 'C++',
  'c#': 'C#',
  '.net': 'C#',
};

const STOPWORDS = new Set([
  'the', 'and', 'for', 'with', 'you', 'your', 'are', 'our', 'this', 'that',
  'from', 'have', 'has', 'was', 'were', 'will', 'can', 'may', 'but', 'not',
  'all', 'any', 'who', 'what', 'when', 'how', 'why', 'use', 'used', 'using',
  'into', 'over', 'than', 'then', 'them', 'they', 'their', 'there', 'about',
]);

// Semantic skill groups: skills in the same group give partial credit.
const SKILL_GROUPS: string[][] = [
  ['JavaScript', 'TypeScript'],
  ['React', 'React Native', 'Next.js', 'Redux'],
  ['Vue', 'Angular', 'Svelte'],
  ['Node.js', 'Express', 'NestJS'],
  ['Django', 'Flask', 'FastAPI'],
  ['MongoDB', 'PostgreSQL', 'MySQL', 'SQLite', 'Redis', 'DynamoDB'],
  ['TensorFlow', 'PyTorch', 'Keras'],
  ['Machine Learning', 'Deep Learning', 'Scikit-learn'],
  ['AWS', 'Azure', 'GCP'],
  ['Docker', 'Kubernetes'],
  ['Power BI', 'Tableau'],
];

const SKILL_TO_GROUP = new Map<string, number>();
SKILL_GROUPS.forEach((group, i) => {
  group.forEach((s) => SKILL_TO_GROUP.set(s, i));
});

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9+#./\s-]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length > 0 && !STOPWORDS.has(t));
}

export function extractSkills(text: string): string[] {
  const found = new Set<string>();
  const lower = text.toLowerCase();

  // 1. Match multi-word skills first (longest match wins).
  for (const skill of SKILL_BANK) {
    const key = skill.toLowerCase();
    if (lower.includes(key)) {
      found.add(skill);
    }
  }

  // 2. Token + alias matching for single-word skills.
  const tokens = tokenize(text);
  for (const tok of tokens) {
    if (SKILL_LOOKUP.has(tok)) {
      found.add(SKILL_LOOKUP.get(tok)!);
    }
    if (ALIASES[tok]) {
      found.add(ALIASES[tok]);
    }
  }

  // 3. Two-word alias scan (e.g. "rest api", "node js").
  for (let i = 0; i < tokens.length - 1; i++) {
    const bigram = `${tokens[i]} ${tokens[i + 1]}`;
    if (ALIASES[bigram]) found.add(ALIASES[bigram]);
  }

  return Array.from(found).sort();
}

export type MatchResult = {
  score: number; // 0-100
  matched: string[];
  missing: string[];
  partial: { resumeSkill: string; jobSkill: string }[];
};

// Jaccard-style scoring with partial credit for semantically related skills.
export function scoreMatch(resumeSkills: string[], jobSkills: string[]): MatchResult {
  const resumeSet = new Set(resumeSkills.map((s) => s.toLowerCase()));
  const matched: string[] = [];
  const missing: string[] = [];
  const partial: { resumeSkill: string; jobSkill: string }[] = [];

  for (const jobSkill of jobSkills) {
    const key = jobSkill.toLowerCase();
    if (resumeSet.has(key)) {
      matched.push(jobSkill);
    } else {
      // Look for a semantic sibling in the resume.
      const groupIdx = SKILL_TO_GROUP.get(jobSkill);
      let sibling: string | null = null;
      if (groupIdx !== undefined) {
        for (const rs of resumeSkills) {
          if (SKILL_TO_GROUP.get(rs) === groupIdx && rs.toLowerCase() !== key) {
            sibling = rs;
            break;
          }
        }
      }
      if (sibling) {
        partial.push({ resumeSkill: sibling, jobSkill });
      } else {
        missing.push(jobSkill);
      }
    }
  }

  const total = jobSkills.length || 1;
  const fullCredit = matched.length;
  const partialCredit = partial.length * 0.5;
  const score = Math.round(((fullCredit + partialCredit) / total) * 100);

  return {
    score: Math.min(100, Math.max(0, score)),
    matched,
    missing,
    partial,
  };
}

// Recommend courses that cover the missing skills, ranked by overlap.
export function recommendCourses(
  missingSkills: string[],
  courses: { id: string; title: string; provider: string; skills: string[]; level: string | null; url: string | null }[]
) {
  const missingSet = new Set(missingSkills.map((s) => s.toLowerCase()));
  return courses
    .map((c) => {
      const overlap = c.skills.filter((s) => missingSet.has(s.toLowerCase()));
      return { course: c, overlap };
    })
    .filter((x) => x.overlap.length > 0)
    .sort((a, b) => b.overlap.length - a.overlap.length);
}