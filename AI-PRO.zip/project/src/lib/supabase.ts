import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type Resume = {
  id: string;
  user_id: string;
  filename: string;
  content: string;
  skills: string[];
  created_at: string;
};

export type Job = {
  id: string;
  title: string;
  company: string;
  location: string | null;
  description: string | null;
  required_skills: string[];
  posted_at: string;
};

export type Course = {
  id: string;
  title: string;
  provider: string;
  skills: string[];
  level: string | null;
  url: string | null;
};

export type Analysis = {
  id: string;
  user_id: string;
  resume_id: string;
  job_id: string;
  match_score: number;
  matched_skills: string[];
  missing_skills: string[];
  created_at: string;
};
